﻿#include <iostream>

int _main()
{
    std::cout << "Hello World!\n";
    return 0;
}
